/**
 * @file hello_world_small.c
 * @brief NIOS Audio - I2S 16-bit Slave mode con Buffer Anti-Jitter
 * @details WM8731 configurado en I2S, 16-bit, Slave, 48kHz
 *          Buffer local desacopla SDRAM del codec para eliminar jitter
 */

#include <stdio.h>
#include <stdint.h>

#define SHARED_MEM_BASE  0x00100000  // SDRAM + 1MB offset
#define AUDIO_BASE       0xFF203040  // Audio codec
#define AV_CONFIG_BASE   0xFF203000  // Audio/Video Config
#define LED_BASE         0xFF200000  // LEDs

#define WM8731_I2C_ADDR  0x34

#define SHMEM_WRITE_IDX  0   // Offset 0x00
#define SHMEM_READ_IDX   1   // Offset 0x04
#define SHMEM_BUFFER_SIZE 2  // Offset 0x08
#define SHMEM_FLAGS      3   // Offset 0x0C
#define SHMEM_SAMPLES    8   // Offset 0x20

/* Buffer local anti-jitter (on-chip memory) */
#define LOCAL_BUFFER_SIZE 512

void wm8731_write_reg(volatile int *av_config_ptr, unsigned char reg, unsigned short value) {
    unsigned int cmd = (WM8731_I2C_ADDR << 16) | ((reg & 0x7F) << 9) | (value & 0x1FF);
    *av_config_ptr = cmd;
    for (volatile int i = 0; i < 100000; i++);
}

int main(void) {
    volatile int *led_ptr = (int *)LED_BASE;
    volatile int *audio_ptr = (int *)AUDIO_BASE;
    volatile int *av_config_ptr = (int *)AV_CONFIG_BASE;
    volatile int *shmem_ptr = (int *)SHARED_MEM_BASE;

    /* Initialize WM8731 codec */
    wm8731_write_reg(av_config_ptr, 15, 0x000);  // Reset
    for (volatile int i = 0; i < 1000000; i++);

    wm8731_write_reg(av_config_ptr, 6, 0x000);   // Power: all on
    wm8731_write_reg(av_config_ptr, 5, 0x000);   // Digital: unmute, NO de-emphasis
    wm8731_write_reg(av_config_ptr, 4, 0x010);   // Analog path: DAC select, bypass
    wm8731_write_reg(av_config_ptr, 7, 0x042);   // Format: I2S, 16-bit
    wm8731_write_reg(av_config_ptr, 8, 0x001);   // Sample rate: 48kHz USB mode
    wm8731_write_reg(av_config_ptr, 2, 0x17F);   // Left volume
    wm8731_write_reg(av_config_ptr, 3, 0x17F);   // Right volume
    wm8731_write_reg(av_config_ptr, 9, 0x001);   // Activate

    /* Clear audio FIFOs */
    *audio_ptr = 0x08;
    *audio_ptr = 0x00;
    for (volatile int i = 0; i < 100000; i++);

    /* Verificar que ARM haya inicializado */
    int buffer_size = *(shmem_ptr + SHMEM_BUFFER_SIZE);
    if (buffer_size != 65536) {
        *led_ptr = 0x3FF;
        while(1);
    }

    *(shmem_ptr + SHMEM_FLAGS) = 0x01;

    /* Esperar buffer inicial */
    int write_idx = 0;
    while (write_idx < 100) {
        write_idx = *(shmem_ptr + SHMEM_WRITE_IDX);
    }

    /* ========================================================================
     * BUFFER LOCAL ANTI-JITTER (on-chip memory)
     * ======================================================================== */
    static int32_t local_buffer[LOCAL_BUFFER_SIZE];
    int local_write_idx = 0;
    int local_read_idx = 0;
    int local_count = 0;

    /* Pre-llenar buffer local (mitad de capacidad) */
    int read_idx = 0;
    int target_prefill = LOCAL_BUFFER_SIZE / 2;

    while (local_count < target_prefill) {
        write_idx = *(shmem_ptr + SHMEM_WRITE_IDX);

        if (write_idx != read_idx) {
            local_buffer[local_write_idx] = *(shmem_ptr + SHMEM_SAMPLES + read_idx);
            local_write_idx = (local_write_idx + 1) % LOCAL_BUFFER_SIZE;
            read_idx = (read_idx + 1) % buffer_size;
            local_count++;
        }
    }

    *(shmem_ptr + SHMEM_READ_IDX) = read_idx;

    *led_ptr = 0x001;  /* LED0 = reproducción iniciada */

    /* Main loop con doble buffer */
    int samples_processed = 0;
    int led_state = 0;

    while (1) {
        /* ====================================================================
         * PASO 1: Rellenar buffer local desde SDRAM (cuando hay espacio)
         * ==================================================================== */
        if (local_count < LOCAL_BUFFER_SIZE - 32) {
            write_idx = *(shmem_ptr + SHMEM_WRITE_IDX);

            int available;
            if (write_idx >= read_idx) {
                available = write_idx - read_idx;
            } else {
                available = buffer_size - read_idx + write_idx;
            }

            /* Leer en ráfaga del SDRAM (hasta 32 samples) */
            int to_read = LOCAL_BUFFER_SIZE - local_count;
            if (to_read > available) to_read = available;
            if (to_read > 32) to_read = 32;

            for (int i = 0; i < to_read; i++) {
                local_buffer[local_write_idx] = *(shmem_ptr + SHMEM_SAMPLES + read_idx);
                local_write_idx = (local_write_idx + 1) % LOCAL_BUFFER_SIZE;
                read_idx = (read_idx + 1) % buffer_size;
                local_count++;
            }

            /* Actualizar read_idx periódicamente */
            if ((samples_processed & 0x3F) == 0) {
                *(shmem_ptr + SHMEM_READ_IDX) = read_idx;
            }
        }

        /* ====================================================================
         * PASO 2: Alimentar codec desde buffer local (timing constante)
         * ==================================================================== */
        int fifospace = *(audio_ptr + 1);
        int wsrc = (fifospace >> 16) & 0xFF;

        while (wsrc > 0 && local_count > 0) {
            /* Leer del buffer LOCAL (sin jitter) */
            int32_t sample32 = local_buffer[local_read_idx];
            local_read_idx = (local_read_idx + 1) % LOCAL_BUFFER_SIZE;
            local_count--;

            /* Escribir al codec (I2S 16-bit) */
            int32_t sample_i2s = sample32 << 16;
            *(audio_ptr + 2) = sample_i2s;
            *(audio_ptr + 3) = sample_i2s;

            samples_processed++;

            /* LED blink cada 10k samples */
            if ((samples_processed % 10000) == 0) {
                led_state = ~led_state;
                *led_ptr = led_state & 0x3FF;
            }

            fifospace = *(audio_ptr + 1);
            wsrc = (fifospace >> 16) & 0xFF;
        }

        /* Detección de underrun del buffer local */
        if (local_count < 10) {
            *led_ptr = 0x200;  /* LED9 = buffer bajo (crítico) */
        }
    }

    return 0;
}
